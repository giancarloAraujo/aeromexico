import React from "react";
import "../estilos.css";
import harry from '../img/Harry-potter-ficcion.jpg';

const PersonajeTarget = ({perj, eliminarPer}) => (
    <div className="targetGeneral">
        <div className="imgSelec"><img src={harry} width="100px" height="100px" className="imgProfile" /></div>
        <div className="infoTag">
            <p className="barInfoEstatus"><span>{perj.estatus}</span>/ESTUDIANTE</p>
            <p className="barInfoName"><strong> <span>{perj.personaje}</span></strong></p>
            <p className="barInfo"><strong>Genero:</strong> <span>{perj.genero}</span></p>
            <p className="barInfo"><strong>Color de ojos:</strong> <span>{perj.ojos}</span></p>
            <p className="barInfo"><strong>Color cabello:</strong> <span>{perj.cabello}</span></p>
            
        
            <div
                className="btnDelete"
                onClick={ () => eliminarPer(perj.personaje)}
            >Eliminar  &times;</div> 
        </div>  
    </div>
);

export default PersonajeTarget;