import React, { Fragment, useState } from "react";
import "../estilos.css"

const Formulario = ({crearPer}) =>{
    //Creando state de personaje

    const [personajeK, actualizaPersonaje] = useState({
        personaje: '',
        genero: '',
        ojos: '',
        cabello: '',
        estatus: ''
    });

    const [error, actualizaError] = useState(false);

    const actualizarState = e =>{
        //console.log(e.target.name);
        actualizaPersonaje({
            ...personajeK,
            [e.target.name]: e.target.value
        })

        //console.log(personaje);
    }

    const {personaje, genero, ojos, cabello, estatus} = personajeK;

    const SubmitPersonaje = e =>{
        e.preventDefault();

        if(personaje.trim() === '' || genero.trim() === '' || ojos.trim() === '' || cabello.trim() === '' || estatus.trim() === ''){
            actualizaError(true);
            return;
        }

        actualizaError(false);

        crearPer(personajeK);
        
        actualizaPersonaje({
            personaje: '',
            genero: '',
            ojos: '',
            cabello: '',
            estatus: ''
        })

    }

    return (
        <Fragment>
            <h2>Crear Personaje</h2>

            {error ? <p className="targetError"><strong>ATENCIÓN  !!!!Todos los campos son obligatorios¡¡¡¡</strong></p> : null}
            <form
                onSubmit={SubmitPersonaje}
            >
                <table>
                    <tr>
                        <td>
                            <label>Mombre personaje: </label>
                        </td>
                        <td>
                            <input 
                                type="text"
                                name="personaje"
                                className="cajaText"
                                placeholder="Nombre del personaje"
                                onChange={actualizarState}
                                value={personaje}
                                autocomplete="off"
                            />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label>Genero: </label>
                        </td>
                        <td>
                            <input 
                                type="text"
                                name="genero"
                                className="cajaText"
                                placeholder="Genero del personaje"
                                onChange={actualizarState}
                                value={genero}
                                autocomplete="off"
                            />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label>Color de ojos: </label>
                        </td>
                        <td>
                            <input 
                                type="text"
                                name="ojos"
                                className="cajaText"
                                placeholder="Color de ojos"
                                onChange={actualizarState}
                                value={ojos}
                                autocomplete="off"
                            />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label>Color de cabello: </label>
                        </td>
                        <td>
                            <input 
                                type="text"
                                name="cabello"
                                className="cajaText"
                                placeholder="Color de cabello"
                                onChange={actualizarState}
                                value={cabello}
                                autocomplete="off"
                            />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label>Estatus del personaje (Vivo/No vivo): </label>
                        </td>
                        <td>
                            <input 
                                type="text"
                                name="estatus"
                                className="cajaText"
                                placeholder="Estatus del personaje"
                                onChange={actualizarState}
                                value={estatus}
                                autocomplete="off"
                            />
                        </td>
                    </tr>

                    <tr>
                        <td 
                            colSpan="2"
                            align="center"
                        ><br></br>
                                <button
                                    type="submit"
                                >Agregar Personaje</button>
                        <br></br>
                        </td>
                    </tr>
                
                </table>
            </form>
        </Fragment>
    );
}

export default Formulario;