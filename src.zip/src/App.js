import React, { Fragment, useState } from "react";
import Formulario from "./componentes/Formulario";
import PersonajeTarget from "./componentes/PersonajeTarget";
import "./estilos.css"

function App() {

  const [personajesT, guaradPErsonajesT] = useState([]);

  const crearPer = persoanjel => {
    
    guaradPErsonajesT([
      ...personajesT,
      persoanjel
    ]);

    
  }
  
  const eliminarPer = nombre =>{
    const nuevosPe = personajesT.filter(per => per.personaje != nombre);
    guaradPErsonajesT(nuevosPe);
  }
  
  return (
    <Fragment>
      <div className="general">
        <div className="row">
          <div className="containerF">
            <Formulario 
              crearPer = {crearPer}
            />
          </div>
          <div className="containerF">
            <h2 >Administra personajes</h2>
            {
            personajesT.map(p => (
              <PersonajeTarget
                perj={p}
                eliminarPer = {eliminarPer}
              />
            ))
            }
          </div>
        </div>
      </div>
    </Fragment>
  );
}

export default App;